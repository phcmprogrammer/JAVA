package com.Christus.Alunos.entity;

public interface File {
	
	public boolean isFile();
	public boolean isDirectory();
	public String getName();

}
