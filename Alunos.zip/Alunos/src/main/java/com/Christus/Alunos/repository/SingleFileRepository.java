package com.Christus.Alunos.repository;

import com.Christus.Alunos.entity.SingleFile;
import org.springframework.data.jpa.repository.JpaRepository;
public interface SingleFileRepository extends JpaRepository <SingleFile, String>{

}
